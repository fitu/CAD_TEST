Revision 2. Millimetres, 100% scale. Meshes are oriented for printing.
Frame: base down. Caps: flat top down. Shafts: small flat down.
Drums, wheel, grip, sleeves and spacers: axis vertical; brim suggested for drums.
fit_coupon is calibration tooling, not an assembly part. Print it before a full set.
Purchase the metal fasteners listed in README. Hardware and apron are excluded.
Untested prototype. See README for assembly order and unresolved physical validation.
