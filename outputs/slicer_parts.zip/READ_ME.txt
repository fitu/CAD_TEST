16 rigid component meshes, in millimetres. Import individually; arrange and orient in your slicer.
Not a print-in-place assembly. The flexible apron is excluded; it needs material development.
Untested prototype: attachment, retention, tolerances and performance are unresolved.
